#ifndef _SEARCHWORDS_H_
#define _SEARCHWORDS_H_


char* find_word( char *str);


#endif
